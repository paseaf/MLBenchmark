In diesem Ordner bitte folgenden Befehl ausführen: mvn install
