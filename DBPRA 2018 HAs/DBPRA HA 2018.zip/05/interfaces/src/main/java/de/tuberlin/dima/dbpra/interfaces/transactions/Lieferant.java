package de.tuberlin.dima.dbpra.interfaces.transactions;

import java.util.Iterator;
import java.util.List;

public class Lieferant {

	int lieferanten_nr;

	String name;

	String adresse;

	int land;

	String telefon;

	double kontostand;

	public List<LiefertEntry> liefertentries;

	int type;

	public Lieferant(int lieferanten_nr, List<LiefertEntry> liefertentries, int type) {
		this(lieferanten_nr, null, null, -1, null, liefertentries, type);
	}

	public Lieferant(int lieferanten_nr, String name, String adresse, int land, String telefon, List<LiefertEntry> liefertentries, int type) {
		this.lieferanten_nr = lieferanten_nr;
		this.name = name;
		this.adresse = adresse;
		this.land = land;
		this.telefon = telefon;
		this.liefertentries = liefertentries;
		this.kontostand = 0.0d;
		this.type = type;
	}

	public Iterator<LiefertEntry> getLiefertEntries() {
		return liefertentries.iterator();
	}

	public int getLieferanten_nr() {
		return lieferanten_nr;
	}

	public String getName() {
		return name;
	}

	public String getAdresse() {
		return adresse;
	}

	public int getLand() {
		return land;
	}

	public String getTelefon() {
		return telefon;
	}

	public double getKontostand() {
		return kontostand;
	}

	/**
	 * !!! DIESE METHODE DARF NICHT ZUR LÖSUNG DER AUSGABE VERWENDET WERDEN !!!
	 * Das aufrufen dieser Methode (direkt, oder durch reflections) führt zur vergabe von 0 Punkten für die komplette Lösung!
	 *
	 * @return
	 */
	public int getType() {
		return type;
	}

}
