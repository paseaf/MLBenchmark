package de.tuberlin.dima.dbpra.interfaces;

import de.tuberlin.dima.dbpra.interfaces.transactions.Bestellung;
import de.tuberlin.dima.dbpra.interfaces.transactions.Lieferant;

import java.sql.*;
import java.util.Iterator;

/**
 * Created by Moritz on 15.05.2015.
 */
public interface SQL5ExercisesInterface {
	void bestellungBearbeiten(Connection connection,  Bestellung bestellung);


	void neueLieferdatenEinfuegen(Connection connection, Lieferant lieferant);
}
