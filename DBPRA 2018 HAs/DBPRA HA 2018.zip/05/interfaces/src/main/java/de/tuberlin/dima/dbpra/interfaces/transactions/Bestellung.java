package de.tuberlin.dima.dbpra.interfaces.transactions;

import java.util.Iterator;
import java.util.List;

public class Bestellung {

	private int bestellnr;

	private List<Bestellposten> posten;

	private boolean valid;

	public Bestellung(int bestellnr, List<Bestellposten> posten, boolean valid) {
		this.bestellnr = bestellnr;
		this.posten = posten;
		this.valid = valid;
	}

	public Iterator<Bestellposten> getBestellposten() {
		return posten.iterator();
	}

	public int getBestell_Nr() {
		return bestellnr;
	}

	public String getStatus() {
		return "O";
	}

	public String getBearbeiter() {
		return "Clerk#000000042";
	}

	public int getVersandprioritaet() {
		return 0;
	}

	public String getBestellprioritaet() {
		return "4-NOT SPECIFIED";
	}

	public int getKunde() {
		return 4450;
	}

	/**
	 * !!! DIESE METHODE DARF NICHT ZUR LÖSUNG DER AUSGABE VERWENDET WERDEN !!!
	 * Das aufrufen dieser Methode (direkt, oder durch reflections) führt zur vergabe von 0 Punkten für die komplette Lösung!
	 *
	 * @return
	 */
	public boolean isValid() {
		return valid;
	}

}
