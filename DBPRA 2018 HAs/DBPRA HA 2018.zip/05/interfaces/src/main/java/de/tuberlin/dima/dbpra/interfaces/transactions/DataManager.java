package de.tuberlin.dima.dbpra.interfaces.transactions;

import java.sql.*;
import java.util.*;


/**
 * Verwaltet Wissen über die Datenbank. Diese Klasse darf _NICHT_ zur Lösung der Übungsaufgabe verwendet werden!
 *
 * @author mleich
 */
public class DataManager {

	Random rand;

	String[] artikel;

	String[] lieferanten;

	String[] versandart;

	String[] versandanweisung;

	String[] bestellids;

	Vector<LiefertEntry> entries;

	Index<String, LiefertEntry> lieferantIndex;

	Index<String, LiefertEntry> artikelIndex;

	int maxBestellung;

	int maxLieferant;

	public DataManager(Connection con) {
		rand = new Random();
		try {
			Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

			// alle möglichen artikel, versandhinweise, usw...
			artikel = getAllValues(statement, "SELECT Artikel_Nr FROM Artikel");
			versandart = getAllValues(statement, "SELECT DISTINCT Versandart FROM Bestellposten");
			versandanweisung = getAllValues(statement, "SELECT DISTINCT Versandanweisung FROM Bestellposten");
			lieferanten = getAllValues(statement, "SELECT lieferanten_nr FROM Lieferant");
			bestellids = getAllValues(statement, "SELECT bestell_nr FROM bestellung");

			// groesste bisherige bestell ID
			statement.execute("select max(bestell_nr) from bestellung");
			ResultSet set = statement.getResultSet();
			set.next();
			maxBestellung = set.getInt(1);
			set.close();

			// groesste bisherige lieferant ID
			statement.execute("select max(Lieferanten_nr) from Lieferant");
			set = statement.getResultSet();
			set.next();
			maxLieferant = set.getInt(1);
			set.close();

			// lieferanten und verfügbare artikel + preise laden
			lieferantIndex = new Index<String, LiefertEntry>();
			artikelIndex = new Index<String, LiefertEntry>();
			statement.execute("SELECT Artikel, Lieferant, Anzahl_Verfuegb, Lieferpreis FROM Liefert");
			set = statement.getResultSet();

			while (set.next()) {
				LiefertEntry entry = new LiefertEntry(set.getString(2).trim(), set.getString(1).trim(), set.getInt(3), set.getDouble(4));
				lieferantIndex.insert(entry.lieferant, entry);
				artikelIndex.insert(entry.artikel, entry);
			}
			set.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Connection con = null;
		try {
			con = DriverManager.getConnection("jdbc:db2://gnu.dima.tu-berlin.de:50000/" + "DBPRA", "grp55", "dbpra=55");
			DataManager manager = new DataManager(con);
			System.out.println("created data manager");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private String[] getAllValues(Statement statement, String query) throws SQLException {
		statement.execute(query);
		ResultSet set = statement.getResultSet();
		LinkedList<String> tmp = new LinkedList<String>();
		while (set.next()) {
			tmp.add(set.getString(1).trim());
		}
		set.close();
		return tmp.toArray(new String[tmp.size()]);
	}

	protected String getRandomArtikel() {
		return artikel[rand.nextInt(artikel.length)];
	}

	protected String getRandomVersandart() {
		return versandart[rand.nextInt(versandart.length)];
	}

	protected String getRandomVersandhinweis() {
		return versandanweisung[rand.nextInt(versandanweisung.length)];
	}

	protected String getRandomBestell_Nr() {
		return bestellids[rand.nextInt(bestellids.length)];
	}

	protected int getNextBestell_Nr() {
		return ++maxBestellung;
	}

	public Bestellung createRandomBestellung(int type) {
		// größe der bestellung
		int size = rand.nextInt(8) + 2;
		Vector<String> artikel = new Vector<String>(size);
		// select keyposition
		int keypos = rand.nextInt(size);
		// bestellposten erstellen
		List<Bestellposten> posten = new LinkedList<Bestellposten>();
		for (int i = 0; i < size; i++) {
			// artikel aussuchen
			String art = null;
			do {
				art = getRandomArtikel();
			} while (artikel.contains(art));
			artikel.add(art);
			// passende Lieferanten suchen
			List<LiefertEntry> lieferanten = artikelIndex.get(art);
			// groeste verfuegbare menge
			int max = 0;
			for (LiefertEntry entry : lieferanten) {
				max = Math.max(max, entry.anzahl);
			}
			int amount;
			if (i == keypos && type == 1) {
				amount = max + rand.nextInt(100) + 1;
			} else {
				amount = rand.nextInt(max) + 1;
			}

			Bestellposten b;
			if (i == keypos && type == 2) {
				b = null;
			} else {
				// kandidaten finden
				List<LiefertEntry> candidates = new LinkedList<LiefertEntry>();
				// 1. kandidaten mit ausreichender menge filtern, dabei minimalen stückpreis bestimmen
				double min_price = Integer.MAX_VALUE;
				for (LiefertEntry entry : lieferanten) {
					if (entry.anzahl >= amount) {
						candidates.add(entry);
						min_price = Math.min(min_price, entry.preis);
					}
				}
				HashSet<String> candidatenames = new HashSet<String>();
				for (LiefertEntry entry : candidates) {
					if (entry.preis == min_price) {
						candidatenames.add(entry.lieferant);
					}
				}
				b = new Bestellposten(art, i + 1, amount, 0.0, "N", "O", new java.util.Date(), new java.util.Date(), new java.util.Date(), getRandomVersandhinweis(), getRandomVersandart(), candidatenames);
			}
			posten.add(b);
		}
		Bestellung bestellung = new Bestellung(getNextBestell_Nr(), posten, type == 0);
		return bestellung;
	}

	protected Bestellung createChangedBestellung(Statement statement, int type) {
		// bestellnummer wählen
		String bestell_nr = getRandomBestell_Nr();
		// alle Posten lesen
		String sql = "select ARTIKEL,POSTENNUMMER,ANZAHL,RABATT,RETOURSTATUS,POSTENSTATUS,VERSANDDATUM,BESTAETIGUNGSDATUM,EMPFANGSDATUM,VERSANDANWEISUNG,VERSANDART,LIEFERANT,PREIS,STEUER from bestellposten where BESTELL_NR = ";
		LinkedList<Bestellposten> tmp = new LinkedList<Bestellposten>();
		try {
			statement.execute(sql + bestell_nr);
			ResultSet set = statement.getResultSet();

			while (set.next()) {
				tmp.add(new Bestellposten(set.getString(1).trim(), set.getInt(2), set.getInt(3), set.getDouble(4), set.getString(5).trim(), set.getString(6).trim(), set.getDate(7), set.getDate(8), set.getDate(9), set.getString(10).trim(), set.getString(11).trim(), null));
			}
			set.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

		// pick random bestellposten and modify
		int index = rand.nextInt(tmp.size());
		Bestellposten posten = tmp.get(index);

		List<LiefertEntry> lieferanten = artikelIndex.get(posten.getArtikel());
		// groeste verfuegbare menge
		int max = 0;
		for (LiefertEntry entry : lieferanten) {
			max = Math.max(max, entry.anzahl);
		}

		int amount;
		if (type == 1) {
			amount = max + rand.nextInt(100) + 1;
		} else {
			amount = rand.nextInt(max) + 1;
		}
		posten.anzahl = amount;

		Bestellung bestellung = new Bestellung(Integer.parseInt(bestell_nr), tmp, type == 0);
		return bestellung;
	}

	protected Lieferant createRandomLieferant(int id, int type) {
		if (id < 0) {
			// neuen lieferanten anlegen
			id = ++maxLieferant;
			// neue posten generieren
			int size = rand.nextInt(17) + 3;
			// select keyposition
			int keypos = rand.nextInt(size);

			List<LiefertEntry> angebot = new LinkedList<LiefertEntry>();
			Vector<String> artikel = new Vector<String>(size);
			for (int i = 0; i < size; i++) {
				if (i == keypos && type == 2) {
					angebot.add(null);
				} else {
					// artikel aussuchen
					String art = null;
					do {
						art = getRandomArtikel();
					} while (artikel.contains(art));
					artikel.add(art);
					// aktuellen durchschnittspreis für diesen artikel ermitteln
					List<LiefertEntry> entries = artikelIndex.get(art);
					double preis = 0.0d;
					for (LiefertEntry e : entries) {
						preis += e.getPreis();
					}
					preis /= (double) entries.size();
					double newprice;
					if (i == keypos && type == 1) {
						// zu großen preis wählen
						newprice = preis * ((rand.nextInt(40) + 111) / 100.0);
					} else {
						// akzeptablen preis wählen
						newprice = preis * ((rand.nextInt(40) + 69) / 100.0);
					}
					newprice = Math.round(newprice * 10) / 10;
					angebot.add(new LiefertEntry(Integer.toString(id), art, rand.nextInt(400) + 50, newprice));
				}
			}

			return new Lieferant(id, "Lieferant" + id, "42 Wallaby Way", rand.nextInt(25), "13-715-945-6730", angebot, type);

		} else {
			// bestehendes angebot ändern
			// irgendeinen lieferanten wählen
			String lieferant = lieferanten[rand.nextInt(lieferanten.length)];
			List<LiefertEntry> angebot = lieferantIndex.get(lieferant);
			List<LiefertEntry> neuesangebot = new LinkedList<LiefertEntry>();
			int keypos = rand.nextInt(angebot.size());
			int i = 0;
			for (LiefertEntry entry : angebot) {

				double newprice = 0.0d;
				if (i == keypos && type == 2) {
					neuesangebot.add(null);
				} else {
					if (type == 1) {
						// preis zu hoch ansetzen
						newprice = entry.getPreis() * ((rand.nextInt(40) + 120) / 100.0);
					} else {
						// akzeptablen preis generieren
						newprice = entry.getPreis() * ((rand.nextInt(40) + 69) / 100.0);
					}

					int anzahl = 0;
					if (i == keypos && type == 3) {
						// zu geringe anzahl generieren
						anzahl = rand.nextInt(entry.getAnzahl());
					} else {
						// ausreichend große anzahl
						anzahl = entry.getAnzahl() + 1 + rand.nextInt(400);
					}
					neuesangebot.add(new LiefertEntry(lieferant, entry.getArtikel(), anzahl, newprice));
				}
				i++;
			}

			return new Lieferant(Integer.parseInt(lieferant), neuesangebot, type);

		}
	}

	protected class Index<K, V> {
		Map<K, List<V>> map;

		Index() {
			map = new HashMap<K, List<V>>();
		}

		void insert(K key, V value) {
			List<V> list = map.get(key);
			if (list == null) {
				list = new LinkedList<V>();
				map.put(key, list);
			}
			list.add(value);
		}

		List<V> get(K key) {
			return map.get(key);
		}
	}
}
