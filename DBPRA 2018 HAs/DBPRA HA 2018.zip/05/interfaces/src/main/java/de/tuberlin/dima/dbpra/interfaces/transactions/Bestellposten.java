package de.tuberlin.dima.dbpra.interfaces.transactions;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;

public class Bestellposten {

	protected static DateFormat format = new SimpleDateFormat("yyyy-MM-dd");

	protected String artikel;

	protected int postennummer;

	protected int anzahl;

	protected double rabatt;

	protected String retourstatus;

	protected String postenstatus;

	protected Date versanddatum;

	protected Date bestaetigungsdatum;

	protected Date empfangsdatum;

	protected String versandanweisung;

	protected String versandart;

	private HashSet<String> candidates;

	private boolean shouldfail = false;

	public Bestellposten(String artikel, int postennummer, int anzahl,
	                     double rabatt, String retourstatus, String postenstatus,
	                     Date versanddatum, Date bestaetigungsdatum, Date empfangsdatum,
	                     String versandanweisung, String versandart, HashSet<String> candidates) {
		this.artikel = artikel;
		this.postennummer = postennummer;
		this.anzahl = anzahl;
		this.rabatt = rabatt;
		this.retourstatus = retourstatus;
		this.postenstatus = postenstatus;
		this.versanddatum = versanddatum;
		this.bestaetigungsdatum = bestaetigungsdatum;
		this.empfangsdatum = empfangsdatum;
		this.versandanweisung = versandanweisung;
		this.versandart = versandart;
		this.candidates = candidates;
	}


	public String getArtikel() {
		return artikel;
	}

	public int getPostennummer() {
		return postennummer;
	}

	public int getAnzahl() {
		return anzahl;
	}

	public double getRabatt() {
		return rabatt;
	}

	public String getRetourstatus() {
		return retourstatus;
	}

	public String getPostenstatus() {
		return postenstatus;
	}

	public String getVersanddatum() {
		return format.format(versanddatum);
	}

	public String getBestaetigungsdatum() {
		return format.format(bestaetigungsdatum);
	}

	public String getEmpfangsdatum() {
		return format.format(empfangsdatum);
	}

	public String getVersandanweisung() {
		return versandanweisung;
	}

	public String getVersandart() {
		return versandart;
	}

	/**
	 * !!! DIESE METHODE DARF NICHT ZUR LÖSUNG DER AUSGABE VERWENDET WERDEN !!!
	 * Das aufrufen dieser Methode (direkt, oder durch reflections) führt zur vergabe von 0 Punkten für die komplette Lösung!
	 *
	 * @return
	 */
	public HashSet<String> getCandidates() {
		return candidates;
	}

	/**
	 * !!! DIESE METHODE DARF NICHT ZUR LÖSUNG DER AUSGABE VERWENDET WERDEN !!!
	 * Das aufrufen dieser Methode (direkt, oder durch reflections) führt zur vergabe von 0 Punkten für die komplette Lösung!
	 *
	 * @return
	 */
	protected boolean shouldFail() {
		return shouldfail;
	}

	protected void setShoudFail(boolean shouldfail) {
		this.shouldfail = shouldfail;
	}

	public void setAnzahl(int anzahl) {
		this.anzahl = anzahl;
	}
}
