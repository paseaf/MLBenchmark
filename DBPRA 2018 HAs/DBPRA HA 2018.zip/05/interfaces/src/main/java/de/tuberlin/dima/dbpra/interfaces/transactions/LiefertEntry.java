package de.tuberlin.dima.dbpra.interfaces.transactions;

public class LiefertEntry {

	public String getLieferant() {
		return lieferant;
	}

	protected String lieferant;

	protected String artikel;

	protected int anzahl;

	protected double preis;

	public LiefertEntry(String lieferant, String artikel, int anzahl, double preis) {
		this.lieferant = lieferant;
		this.artikel = artikel;
		this.preis = preis;
		this.anzahl = anzahl;
	}

	public String getArtikel() {
		return artikel;
	}

	public int getAnzahl() {
		return anzahl;
	}

	public double getPreis() {
		return preis;
	}

}
