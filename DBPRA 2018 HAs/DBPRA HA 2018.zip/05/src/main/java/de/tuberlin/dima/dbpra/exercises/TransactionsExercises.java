package de.tuberlin.dima.dbpra.exercises;

import de.tuberlin.dima.dbpra.interfaces.SQL5ExercisesInterface;
import de.tuberlin.dima.dbpra.interfaces.transactions.Bestellposten;
import de.tuberlin.dima.dbpra.interfaces.transactions.Bestellung;
import de.tuberlin.dima.dbpra.interfaces.transactions.Lieferant;
import de.tuberlin.dima.dbpra.interfaces.transactions.LiefertEntry;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;

public class TransactionsExercises implements SQL5ExercisesInterface {

    /*
        Aufgabenstellung:

        Fügen Sie eine eingehende Bestellung in das System ein. Hierfür müssen die
        Bestellung und die dazugehörigen Bestellposten in die jeweiligen Tabellen eingefügt
        werden. Jeder Bestellposten muss einem Lieferanten zugeordnet werden. Wählen sie
        einen Lieferanten, der die geforderte Anzahl an Artikeln liefern kann und dabei den
        kleinstmöglichen Lieferpreis bietet. Ein Bestellposten darf nur genau von einem
        Lieferanten geliefert werden. Es ist also nicht erlaubt eine Bestellung von 100
        Quietscheentchen auf 2 Lieferanten zu verteilen, die jeweils 50 Quietscheentchen
        liefern können!

        Der Wert Preis des Bestellpostens (die vom Kunden zu zahlende Summe) darf von
        Ihnen selbst festgelegt werden, er muss über dem Wert Lieferpreis * Anzahl liegen.

        Die Felder Rabatt und Steuer sollen ignoriert werden. (0.0 bei neuen Bestellposten,
        lassen Sie diese Werte nicht in die Berechnung des Preises einfließen!).

        Der Gesamtpreis einer Bestellung ergibt sich aus der Summer der Preise aller
        Bestellposten dieser Bestellung (auch hier sollen Steuern und Rabatte ignoriert
        werden!).

        Reduzieren sie ebenfalls bei jedem Lieferanten, den Sie zum Bearbeiten des
        Bestellpostens verwenden, die Anzahl der verfügbaren Artikel um die Anzahl der im
        Posten bestellten Artikel.

        Verwenden Sie zum Einfügen der Bestellung und Bestellposten in die Datenbank wenn
        möglich die Werte des Bestellungsobjektes und des Bestellpostenobjektes.

        Die vom Iterator gelieferten Bestellposten können den Wert null haben. Werten Sie das
        als den Abbruch der Bestellung durch Kunden und brechen Sie die gesamte
        Transaktion ab.

        Der gesamte Vorgang soll als einzelne Transaktion umgesetzt werden. Wählen Sie für
        die Transaktion das schwächst mögliche Isolationslevel, dass die korrekte
        konkurrierende Ausführung aller in dieser Hausaufgabe zu implementierenden
        Transaktionen ermöglicht. (Gehen Sie also davon aus, dass mehrere Bestellungen
        parallel in die Datenbank eingefügt werden und gleichzeitig mehrere Lieferanten parallel
        ihr Angebot aktualisieren, bzw. neue Lieferanten neue Angebote machen.)

        Brechen Sie die Transaktion ebenfalls ab, wenn ein oder mehr Bestellposten nicht in
        ausreichender Menge geliefert werden können.
    */
	public void bestellungBearbeiten(Connection connection, Bestellung bestellung) {
        try {

            String query;

            // protect against dirty read
            connection.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
            // autocommit ausschalten
            connection.setAutoCommit(false);

            // füge bestellung ein
            query = "INSERT INTO BESTELLUNG VALUES (?, ?, ?, ?, CURRENT_DATE, ?, ?, ?)";
            PreparedStatement insertBestellung = connection.prepareStatement(query);
            insertBestellung.setInt(1, bestellung.getBestell_Nr());
            insertBestellung.setInt(2, bestellung.getKunde());
            insertBestellung.setString(3, bestellung.getStatus());
            insertBestellung.setDouble(4, 0.0);
            insertBestellung.setString(5, bestellung.getBestellprioritaet());
            insertBestellung.setString(6, bestellung.getBearbeiter());
            insertBestellung.setInt(7, bestellung.getVersandprioritaet());
            insertBestellung.executeUpdate();

            /*
            * Iterator über Bestellposten
            * */
            int lieferant_id;
            double lieferant_preis = 0.0;
            Iterator<Bestellposten> posten = bestellung.getBestellposten();
            while(posten.hasNext()) {

                Bestellposten bestellposten = posten.next();
                // abbruch der transaktion durch kunde
                if(bestellposten == null) {
                    connection.rollback();
                    return;
                } else {
                    // lieferanten die die geforderte anzahl zum geringsten Preis liefern
                    query = "SELECT * FROM LIEFERT" +
                                " WHERE ARTIKEL = " + Integer.parseInt(bestellposten.getArtikel()) +
                                " AND ANZAHL_VERFUEGB >= " + bestellposten.getAnzahl() +
                                " AND LIEFERPREIS = (SELECT min(LIEFERPREIS) FROM Liefert" +
                                    " WHERE ARTIKEL = " + Integer.parseInt(bestellposten.getArtikel()) +
                                    " AND  ANZAHL_VERFUEGB >= " + bestellposten.getAnzahl() + ")";
                    ResultSet resultSet = connection.createStatement().executeQuery(query);

                    // check if order can be filled
                    if(resultSet.next()) {
                        lieferant_id = resultSet.getInt("LIEFERANT");
                        double lieferpreis = resultSet.getDouble("LIEFERPREIS");
                        lieferant_preis += (lieferpreis * bestellposten.getAnzahl() * 1.25);
                    } else {
                        connection.rollback();
                        return;
                    }

                    /*
                     * BESTELLPOSTEN einfügen:
                     * preis > lieferpreis * anzahl
                     * rabatt / steuer = 0.0 bei neuen bestellposten
                     * gesamtpreis = summe der preise aller bestellposten dieser bestellung
                     * */
                    query = "INSERT INTO BESTELLPOSTEN VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement insertBestellposten = connection.prepareStatement(query);
                    insertBestellposten.setInt(1, bestellung.getBestell_Nr());
                    insertBestellposten.setInt(2, Integer.parseInt(bestellposten.getArtikel()));
                    insertBestellposten.setInt(3, lieferant_id);
                    insertBestellposten.setInt(4, bestellposten.getPostennummer());
                    insertBestellposten.setDouble(5, bestellposten.getAnzahl());
                    insertBestellposten.setDouble(6, lieferant_preis);
                    insertBestellposten.setDouble(7, 0.0);
                    insertBestellposten.setDouble(8, 0.0);
                    insertBestellposten.setString(9, bestellposten.getRetourstatus());
                    insertBestellposten.setString(10, bestellposten.getPostenstatus());
                    insertBestellposten.setString(11, bestellposten.getVersanddatum());
                    insertBestellposten.setString(12, bestellposten.getBestaetigungsdatum());
                    insertBestellposten.setString(13, bestellposten.getEmpfangsdatum());
                    insertBestellposten.setString(14, bestellposten.getVersandanweisung());
                    insertBestellposten.setString(15, bestellposten.getVersandart());
                    insertBestellposten.executeUpdate();

                    // LIEFERT updaten
                    query = "UPDATE LIEFERT SET LIEFERT.ANZAHL_VERFUEGB = LIEFERT.ANZAHL_VERFUEGB - ? WHERE LIEFERT.LIEFERANT = ? AND LIEFERT.ARTIKEL = ?";
                    PreparedStatement updateLiefert = connection.prepareStatement(query);
                    updateLiefert.setInt(1, bestellposten.getAnzahl());
                    updateLiefert.setInt(2, lieferant_id);
                    updateLiefert.setInt(3, Integer.parseInt(bestellposten.getArtikel()));
                    updateLiefert.executeUpdate();
                }
            }

            // BESTELLUNG updaten
            query = "UPDATE BESTELLUNG SET BESTELLUNG.GESAMTPREIS = ? WHERE BESTELLUNG.BESTELL_NR = ?";
            PreparedStatement updateBestellung = connection.prepareStatement(query);
            updateBestellung.setDouble(1, lieferant_preis);
            updateBestellung.setInt(2, bestellung.getBestell_Nr());
            updateBestellung.executeUpdate();

            // commit
            connection.commit();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            try {
                connection.rollback();
            } catch (SQLException sql) {
                System.out.println(sql.getErrorCode());
            }
        }
	}

	/*
	Ein Lieferant übermittelt Ihnen aktualisierte Preise und neue Lieferkontingente für seine
    Artikel. Entscheiden Sie, ob Sie die neuen Lieferbedingungen annehmen oder bei den
    alten Werten bleiben und führen Sie ggf. alle nötigen Änderungen durch.

    Bei einem bereits bestehenden Lieferanten darf beim neuen Angebot der
    durchschnittliche Einzelpreis aller von ihm angebotenen Artikel nicht größer als 110%
    des ursprünglichen durchschnittlichen Einzelpreises seiner Artikel sein (Ablehnen von
    extremer Preissteigerung).

    Ein bestehender Lieferant muss die verfügbare Anzahl jedes Artikels erhöhen, nicht
    senken oder unverändert lassen. (Das bewirkt, dass dieser Versandhandel das zuvor
    zugesicherte Kontingent immer ausschöpfen kann) Sie müssen davon ausgehen, dass
    ein Angebot eines bestehenden Lieferanten immer jeden Artikel, den dieser Lieferant
    anbietet, beinhaltet. Ein bestehender Lieferant macht also keine Angebote für neue
    Artikel und nimmt auch keine Artikel aus dem Angebot heraus.

    Das Angebot neuer Lieferanten darf nur in die Datenbank eingefügt werden, wenn für
    jeden Artikel folgende Bedingung gilt: der Einzelpreis des Artikels ist nicht größer als
    110% des durchschnittlichen Einzelpreises des Artikels der bestehenden Händler

    Sie müssen davon ausgehen, dass neue Lieferanten Ihnen nur Angebote zu Artikeln
    machen, die sich bereits in ihrer Datenbank befinden.

    Bestehende Lieferanten ändern nur ihr Angebot, sie müssen also nicht die
    Telefonnummer oder Adresse bestehender Lieferanten aktualisieren.

    Neue Lieferanten müssen natürlich auch in die Lieferant-Tabelle eingefügt werden.

    Der gesamte Vorgang soll als einzelne Transaktion umgesetzt werden. Wählen Sie für
    die Transaktion das schwächst mögliche Isolationslevel, dass die korrekte
    konkurrierende Ausführung aller in dieser Hausaufgabe zu implementierenden
    Transaktionen ermöglicht.

    Gehen Sie also davon aus, dass mehrere Lieferanten parallel ihr Angebot aktualisieren,
    bzw. neue Lieferanten neue Angebote machen und dass gleichzeitig mehrere
    Bestellungen parallel in die Datenbank eingefügt werden. Gehen Sie ebenfalls davon
    aus, dass ein Lieferant niemals gleichzeitig mehrere neue Angebote abgibt.
	* */
	public void neueLieferdatenEinfuegen(Connection connection,  Lieferant lieferant) {
        try {
            ResultSet resultSet;
            String query;

            // protect against dirty read
            connection.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
            connection.setAutoCommit(false);

            boolean addLieferant = false;

            //
            query = "SELECT LIEFERANTEN_NR FROM LIEFERANT WHERE LIEFERANTEN_NR = " + lieferant.getLieferanten_nr();
            resultSet = connection.createStatement().executeQuery(query);

            if(!resultSet.next()) {
                try {
                    query = "INSERT INTO LIEFERANT VALUES (?, ?, ?, ?, ?, ?)";
                    PreparedStatement insertLieferant = connection.prepareStatement(query);
                    insertLieferant.setInt(1, lieferant.getLieferanten_nr());
                    insertLieferant.setString(2, lieferant.getName());
                    insertLieferant.setString(3, lieferant.getAdresse());
                    insertLieferant.setInt(4, lieferant.getLand());
                    insertLieferant.setString(5, lieferant.getTelefon());
                    insertLieferant.setDouble(6, lieferant.getKontostand());
                    insertLieferant.executeUpdate();
                } catch (SQLException sql) {
                    System.out.println(sql.getErrorCode());
                }
                addLieferant = true;
            }

            //
            double avgPreis = 0.0;
            Iterator<LiefertEntry> liefert_avg = lieferant.getLiefertEntries();
            int size = 0;
            while(liefert_avg.hasNext()) {
                avgPreis += liefert_avg.next().getPreis();
                size++;
            }
            avgPreis = (avgPreis / size);

            //
            double lieferantAvgLieferpreis = 0.0;
            query = "SELECT avg(LIEFERPREIS) AS AVG_LIEFERPREIS FROM LIEFERT WHERE LIEFERANT = " + lieferant.getLieferanten_nr();
            resultSet = connection.createStatement().executeQuery(query);
            if(resultSet.next()) {
                lieferantAvgLieferpreis = resultSet.getDouble("AVG_LIEFERPREIS");
            }

            //
            if(lieferantAvgLieferpreis == -1) {
                connection.rollback();
                return;
            }

            Iterator<LiefertEntry> liefert = lieferant.getLiefertEntries();
            while(liefert.hasNext()) {
                LiefertEntry posten = liefert.next();

                if(!addLieferant) {
                    query = "SELECT ANZAHL_VERFUEGB AS ANZAHL FROM LIEFERT" +
                            " WHERE LIEFERANT = " + lieferant.getLieferanten_nr() +
                            " AND ARTIKEL = " + Integer.parseInt(posten.getArtikel());
                    resultSet = connection.createStatement().executeQuery(query);

                    int anzahl;
                    if(resultSet.next()) {
                        anzahl = resultSet.getInt("ANZAHL");
                    } else {
                        connection.rollback();
                        return;
                    }

                    if(posten.getAnzahl() <= anzahl || avgPreis > (1.1 * lieferantAvgLieferpreis)) {
                        connection.rollback();
                        return;
                    }

                    query = "UPDATE LIEFERT SET ANZAHL_VERFUEGB = ? , LIEFERPREIS= ? WHERE LIEFERANT = ? AND ARTIKEL = ?";
                    PreparedStatement updateLiefert = connection.prepareStatement(query);
                    updateLiefert.setInt(1, posten.getAnzahl());
                    updateLiefert.setDouble(2, posten.getPreis());
                    updateLiefert.setInt(3, lieferant.getLieferanten_nr());
                    updateLiefert.setInt(4, Integer.parseInt(posten.getArtikel()));
                    updateLiefert.executeUpdate();
                } else {
                    query = "SELECT avg(LIEFERPREIS) AS AVG_LIEFERPREIS FROM LIEFERT" +
                            " WHERE ARTIKEL = " + Integer.parseInt(posten.getArtikel());
                    resultSet = connection.createStatement().executeQuery(query);

                    double avgLieferpreis = 0.0;
                    if(resultSet.next()) {
                        avgLieferpreis = resultSet.getDouble("AVG_LIEFERPREIS");
                    }
                    if(posten.getPreis() <= (1.1 * avgLieferpreis)) {
                        query = "INSERT INTO LIEFERT VALUES (?,?,?,?)";
                        PreparedStatement insertLiefert = connection.prepareStatement(query);
                        insertLiefert.setInt(1, Integer.parseInt(posten.getArtikel()));
                        insertLiefert.setInt(2, lieferant.getLieferanten_nr());
                        insertLiefert.setInt(3, posten.getAnzahl());
                        insertLiefert.setDouble(4, posten.getPreis());
                        insertLiefert.executeUpdate();
                    } else {
                        connection.rollback();
                        return;
                    }
                }
            }
            connection.commit();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            try {
                connection.rollback();
            } catch (SQLException sql) {
                System.out.println(sql.getErrorCode());
            }
        }
    }
}