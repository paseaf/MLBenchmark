package de.tuberlin.dbpra.mapreduce.rail;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;


/*
 * Reduces a set of intermediate values which share a key to a smaller set of values
 * 1. shuffle: The Reducer copies the sorted output from each Mapper using HTTP across the network.
 * 2. sort: The framework merge sorts Reducer inputs by keys (since different Mappers may have output the same key).
 * 3. reduce: In this phase the reduce(Object, Iterable, Context) method is called for each <key, (collection of values)> in the sorted inputs.
 * */

// Reducer <input-key, input-value, output-key, output-value>
public class RailReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

    private IntWritable anzahl = new IntWritable();

    /*
     * reduce() : verarbeitet einen key und alle dazugehörigen values
     * returns either none, one or many key-value pairs
     * */
	@Override
	public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {

        int sum = 0;
        for (IntWritable val : values) {
            sum += val.get();
        }

        anzahl.set(sum);
        context.write(key, anzahl);
	}
}
