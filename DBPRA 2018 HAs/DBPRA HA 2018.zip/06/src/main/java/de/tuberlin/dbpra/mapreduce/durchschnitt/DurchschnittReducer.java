package de.tuberlin.dbpra.mapreduce.durchschnitt;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class DurchschnittReducer extends Reducer<Text, Text, Text, DoubleWritable> {

    private DoubleWritable average = new DoubleWritable();

	public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

        double sum = 0;
        int count = 0;

        for (Text val : values) {
            sum += Double.parseDouble(val.toString());
            count++;
        }

        average.set(sum / count);

        context.write(key, average);
	}
}
