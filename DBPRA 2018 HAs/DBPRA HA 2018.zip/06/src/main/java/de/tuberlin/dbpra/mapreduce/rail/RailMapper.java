package de.tuberlin.dbpra.mapreduce.rail;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

/*
* Maps input key/value pairs to a set of intermediate key/value pairs.
* */
public class RailMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

    private IntWritable anzahl = new IntWritable();
    private Text versanddatum = new Text();

	@Override
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

        String[] result = value.toString().split("\n");

        for (int i = 0; i < result.length; i++) {

            String[] col = result[i].split("\\|");

            if(col[14].equals("RAIL")) {
                versanddatum.set(col[10].substring(0,7));
                //sum = new IntWritable(Integer.parseInt(col[4]));
                anzahl.set(Integer.parseInt(col[4]));
                context.write(versanddatum, anzahl);
            }
        }
	}
}
