package de.tuberlin.dbpra.mapreduce.durchschnitt;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class DurchschnittMapper extends Mapper<LongWritable, Text, Text, Text> {

    private Text id = new Text();
    private Text anzahl = new Text();

	@Override
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

        String[] result = value.toString().split("\n");

        for (int i = 0; i < result.length; i++) {

            String[] col = result[i].split("\\|");

            id.set(col[1]);
            anzahl.set(col[4]);

            context.write(id, anzahl);
        }
	}
}
