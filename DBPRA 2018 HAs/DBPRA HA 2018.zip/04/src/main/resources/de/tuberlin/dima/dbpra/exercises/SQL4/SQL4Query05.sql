-- Aufgabe 5:
-- areaUnderCurveSP
-- (siehe Folien)
--
-- Punkte:
-- 3
--
CREATE PROCEDURE ComputeAreaUnderCurve()
BEGIN
  DECLARE area DOUBLE;
  DECLARE msseries INT;
  DECLARE length INT;
  DECLARE x DOUBLE;
  DECLARE y DOUBLE;
  DECLARE x2 DOUBLE;
  DECLARE y2 DOUBLE;
  DECLARE r1 INT;
  DECLARE r2 INT;
  DECLARE count INT;
  FOR ms AS
  SELECT SERIES
  FROM MESSUNGEN
  GROUP BY SERIES
  DO
    SET area = 0;
    SET msseries = ms.SERIES;
    SET length = (SELECT count(*) FROM MESSUNGEN WHERE MESSUNGEN.Series = msseries);
    SET r1 = 1;
    SET r2 = 2;
    SET count = 1;
    WHILE count < length DO
      SET x = (SELECT a.x AS x
                FROM (SELECT ROWNUMBER() OVER(ORDER BY x) AS rn, x, y
                      FROM MESSUNGEN
                      WHERE MESSUNGEN.series = msseries) AS a
                      WHERE a.rn = r1);
      SET x2 = (SELECT b.x AS x
                FROM (SELECT ROWNUMBER() OVER(ORDER BY x) AS rn, x, y
                      FROM MESSUNGEN
                      WHERE MESSUNGEN.series = msseries) AS b
                      WHERE b.rn = r2);
      SET y = (SELECT c.y AS y
                FROM (SELECT ROWNUMBER() OVER(ORDER BY x) AS rn, x, y
                      FROM MESSUNGEN
                      WHERE MESSUNGEN.series = msseries) AS c
                      WHERE c.rn = r1);
      SET y2 = (SELECT d.y AS y
                FROM (SELECT ROWNUMBER() OVER(ORDER BY x) AS rn, x, y
                      FROM MESSUNGEN
                      WHERE MESSUNGEN.series = msseries) AS d
                      WHERE d.rn = r2);
      SET area= area + (((x2 - x) / 2) * (y2 + y));
      SET r1 = r1 + 1;
      SET r2 = r2 + 1;
      SET count = count + 1;
    END WHILE;
    IF msseries IN (SELECT series FROM area_under_curve) THEN
      UPDATE area_under_curve
      SET area = area
      WHERE series = msseries;
    ELSE
      INSERT INTO area_under_curve VALUES (msseries, area);
    END IF;
  END FOR;
END