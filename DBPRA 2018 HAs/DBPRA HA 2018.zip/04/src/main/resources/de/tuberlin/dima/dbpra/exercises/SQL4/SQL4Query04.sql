-- Aufgabe 4:
-- (siehe Folien)
--
-- Punkte:
-- 2.0
--
CREATE TRIGGER PolarMessungen_Update
INSTEAD OF UPDATE ON PolarMessungen
REFERENCING
OLD AS old
NEW AS new
  FOR EACH ROW
  UPDATE MESSUNGEN
    SET MESSUNGEN.x = new.R * COS(new.THETA), MESSUNGEN.y = new.R * SIN(new.THETA)
    WHERE old.series = new.series AND old.id = new.id