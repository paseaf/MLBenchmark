-- Aufgabe 3:
-- MessungStatistik
-- (siehe Folien)
--
-- Punkte:
-- 1.5
--
CREATE VIEW MessungStatistik AS (
  SELECT
    series,
    (ThetaMax - ThetaMin) AS AngularSpread,
    average AS AvgLength
    FROM (
      SELECT
        series,
        max(Theta(x,y)) AS ThetaMax,
        min(Theta(x,y)) AS ThetaMin,
        avg(R(x,y)) AS average
        FROM Messungen
        GROUP BY series
    )
)