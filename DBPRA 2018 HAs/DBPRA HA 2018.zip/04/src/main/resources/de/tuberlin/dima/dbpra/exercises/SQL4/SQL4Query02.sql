-- Aufgabe 2:
-- Messungen
-- (siehe Folien)
--
-- Punkte:
-- 1.5
--
CREATE VIEW PolarMessungen AS (
  SELECT
    SERIES,
    ID,
    R(x,y) AS R,
    THETA(x,y) AS THETA
  FROM Messungen
)