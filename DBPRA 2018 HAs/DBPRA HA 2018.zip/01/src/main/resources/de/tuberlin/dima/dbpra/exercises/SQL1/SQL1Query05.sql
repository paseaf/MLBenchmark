-- Queryergebnis:
-- Geben Sie die Bestellnummer, das Datum und den Status von Bestellungen aus, deren Status "F" ist,
-- die in einem Oktober vor 1994 aufgegeben wurden und entweder eine Bestellnummer kleiner als 10000
-- oder größer als 500000 besitzen. Ordnen Sie nach Bestellnummern absteigend.
-- <p/>
-- Ergebnisschema:
-- [Bestell_Nr (↓) | Bestelldatum | Status]
-- <p/>
-- Punkte:
-- 3.0
--
-- @return SQL Query für Aufgabe 5
SELECT BESTELL_NR, BESTELLDATUM, STATUS
FROM BESTELLUNG
WHERE STATUS = 'F'
      AND YEAR(BESTELLDATUM) < 1994
      AND MONTH(BESTELLDATUM) = 10
      AND (BESTELL_NR < 10000 OR BESTELL_NR > 50000)
ORDER BY BESTELL_NR DESC;