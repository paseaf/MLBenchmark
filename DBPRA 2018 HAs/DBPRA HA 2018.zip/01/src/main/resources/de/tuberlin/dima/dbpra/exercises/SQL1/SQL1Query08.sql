-- Queryergebnis:
-- Geben Sie die Anzahl und die Summe der Kontostände (Bilanz) aller Kunden aus der Branche AUTOMOBILE aus.
-- <p/>
-- Ergebnisschema:
-- [Anzahl|Bilanz]
-- <p/>
-- Punkte:
-- 1.0
--
-- @return SQL Query für Aufgabe 8
SELECT COUNT(KUNDEN_NR) AS ANZAHL, SUM(KONTOSTAND) AS BILANZ
FROM KUNDE
WHERE BRANCHE = 'AUTOMOBILE';
