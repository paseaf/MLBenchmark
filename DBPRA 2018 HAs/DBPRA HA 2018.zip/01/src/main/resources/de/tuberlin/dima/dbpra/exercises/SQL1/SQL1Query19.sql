-- Queryergebnis:
-- Geben sie für jeden Hersteller aus, wie viel Rabatt im Durchschnitt beim Verkaufen ihrer Artikel gewährt wird.
-- Hinweis: Das Attribut "Rabatt" der Tabelle "Bestellposten" enthält den prozentualen Rabatt, bezogen auf den Gesamtpreis.
-- Geben Sie im Ergebnis den absoluten Rabatt aus.
-- <p/>
-- Ergebnisschema:
-- [Hersteller | Rabatt]
-- <p/>
-- Punkte:
-- 4.0
--
-- @return SQL Query für Aufgabe 19
SELECT ARTIKEL.HERSTELLER AS HERSTELLER, AVG(BESTELLPOSTEN.PREIS * BESTELLPOSTEN.RABATT) AS RABATT
FROM BESTELLPOSTEN JOIN ARTIKEL ON ARTIKEL = ARTIKEL_NR
GROUP BY ARTIKEL.HERSTELLER;

