-- Queryergebnis:
-- Finden Sie für jede mögliche Kombination aus Versandart und Retourstatus die maximale Bearbeitungszeit und
-- die mittlere Bearbeitungszeit (zwischen Empfang und Versand des Postens) absteigend sortiert nach durchschnittlicher Bearbeitungszeit.
-- Betrachten sie nur Kombinationen deren Bestellposten einen Gesamt-Mindestumsatz (siehe Q11) von 1000000000 erreichen.
-- <p/>
-- Ergebnisschema:
-- [versandart | retourstatus | max_zeit | durch_zeit↓]
-- <p/>
-- Punkte:
-- 4.0
--
-- @return SQL Query für Aufgabe 14
SELECT VERSANDART, RETOURSTATUS, MAX(EMPFANGSDATUM - VERSANDDATUM) AS MAX_ZEIT, AVG(EMPFANGSDATUM - VERSANDDATUM) AS DURCH_ZEIT
FROM BESTELLPOSTEN
GROUP BY VERSANDART, RETOURSTATUS
  HAVING SUM(PREIS + PREIS * STEUER) >= 1000000000
ORDER BY AVG(EMPFANGSDATUM - VERSANDDATUM) DESC;