-- Queryergebnis:
-- Finden Sie Kunden (mit Kundennummer, Name, Telefonnummer und deren Land) und erzeugtem Verlust, den sie durch zurückgegebene Artikel erzeugt haben.
-- Geben Sie nur die Top 20 Kunden aus, die den meisten Verlust erzeugt haben. Hinweis, Retourstatus 'R' bedeutet zurückgegeben.
-- <p/>
-- Ergebnisschema:
-- [Kunden_Nr | Name | Telefon | Land | Verlust (↓)]
-- <p/>
-- Punkte:
-- 8.0
--
-- @return SQL Query für Aufgabe 22

SELECT *
FROM KUNDE JOIN
(SELECT BESTELLUNG.KUNDE
FROM BESTELLPOSTEN JOIN BESTELLUNG ON BESTELLPOSTEN.BESTELL_NR = BESTELLUNG.BESTELL_NR
WHERE BESTELLPOSTEN.RETOURSTATUS = 'R')
ON KUNDE.KUNDEN_NR = KUNDE
WHERE KUNDE.KONTOSTAND < 0

-- all returned posten
SELECT BESTELLUNG.KUNDE, BESTELLPOSTEN.PREIS
FROM BESTELLPOSTEN JOIN BESTELLUNG ON BESTELLPOSTEN.BESTELL_NR = BESTELLUNG.BESTELL_NR
WHERE BESTELLPOSTEN.RETOURSTATUS = 'R'
