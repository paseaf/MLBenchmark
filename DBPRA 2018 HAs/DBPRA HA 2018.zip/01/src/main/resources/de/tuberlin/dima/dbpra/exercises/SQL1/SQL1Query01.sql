-- Queryergebnis:
-- Geben sie alle Ländernamen in absteigender alphabetischer Reihenfolge aus.
-- <p/>
-- Ergebnisschema:
-- [Name (↓)]
-- <p/>
-- Punkte:
-- 1.0
--
-- @return SQL Query für Aufgabe 1
SELECT NAME
FROM LAND
ORDER BY NAME DESC;