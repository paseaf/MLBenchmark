-- Queryergebnis:
-- Geben Sie aus, wie viele Kunden aus jeder Region kommen, aufsteigend sortiert nach Namen der Region.
-- <p/>
-- Ergebnisschema:
-- [Region (↑) | Anzahl]
-- <p/>
-- Punkte:
-- 3.0
--
-- @return SQL Query für Aufgabe 17
SELECT REGION_NAME AS Region, COUNT(DISTINCT KUNDEN_NR) AS Anzahl
FROM KUNDE
  JOIN (SELECT REGION.NAME AS REGION_NAME, LAND.LAND_ID
        FROM REGION JOIN LAND ON REGION.REGION_ID = LAND.REGION)
    ON KUNDE.LAND = LAND_ID
GROUP BY REGION_NAME
ORDER BY REGION_NAME ASC;