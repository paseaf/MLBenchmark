-- Queryergebnis:
-- Ermitteln sie für alle Versandarten die Gesamtanzahl und den durchschnittlichen Preis aller Bestellposten, bei denen der Rabatt kleiner als 0.08 ist.
-- Sortieren sie absteigend nach der Versandart.
-- <p/>
-- Ergebnisschema:
-- [Versandart ↓ | Summe | Durchschnitt]
-- <p/>
-- Punkte:
-- 2.0
--
-- @return SQL Query für Aufgabe 10
SELECT VERSANDART, SUM(ANZAHL) AS SUMME, AVG(PREIS) AS DURCHSCHNITT
FROM BESTELLPOSTEN
WHERE RABATT < 0.08
GROUP BY VERSANDART
ORDER BY VERSANDART DESC;