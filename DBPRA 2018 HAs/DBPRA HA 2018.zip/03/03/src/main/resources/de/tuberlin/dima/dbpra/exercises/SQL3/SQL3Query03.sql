-- Aufgabe 3:
-- Funktion um der Tabelle KundenKontaktDaten ein check constraint
-- mit dem Namen TwitterID_Check auf das Attribut Twitter_ID hinzuzufügen.
--
-- Das Check Constraint soll sicher stellen dass:
-- - Alle Twitter_IDs mit @ anfangen.
-- - Und nach dem @ eine Zeichenkette folgt, die
-- o Maximal 31 Zeichen lang ist
-- o Nur aus kleinen lateinische Buchstaben, Zahlen, und '_' besteht.
--
-- Punkte:
-- 2
--
ALTER TABLE KUNDENKONTAKTDATEN
ADD CONSTRAINT TwitterID_Check
CHECK(
  -- starts with '@'
  Twitter_ID LIKE '@%'
  AND
  -- followed by 31 chars max
  LENGTH(TRIM(SUBSTR(Twitter_ID,2))) <= 31
  AND
  -- only lowercase, numbers and '_'
  LENGTH(REPLACE(TRANSLATE(SUBSTR(Twitter_ID,2), '','abcdefghijklmnopqrstuvwxyz0123456789_'), ' ', '')) = 0
);