-- Aufgabe 5:
-- Funktion um der Tabelle KundenKontaktDaten ein check constraint
-- mit dem Namen Telefonnummer_CHECK auf das Attribut Telefonnummer
-- hinzuzufügen.
--
-- Das Check Constraint soll sicher stellen dass:
-- - Jede Nummer die Landvorwahl für Deutschland +49 hat
-- - Nach der +49 Vorwahl eine Zahl zwischen 150 und 180 folgt
-- - Nach der Netzvorwahl zwischen 8 und 10 Ziffern kommen
-- - Landesvorwahl, Netzvorwahl und Nummer durch ein Leerzeichen getrennt
-- werden
--
-- Punkte:
-- 2
--
ALTER TABLE KUNDENKONTAKTDATEN
ADD CONSTRAINT Telefonnummer_CHECK
CHECK (
  -- number starts with +49
  TELEFONNUMMER LIKE '+49%'
  AND
  -- followed by space
  SUBSTR(TELEFONNUMMER, 4, 1) LIKE ' '
  AND
  -- 3 digit number
  LENGTH(REPLACE(TRANSLATE(SUBSTR(TELEFONNUMMER, 5, 3), '','0123456789'), ' ', '')) = 0
  AND
  -- no spaces
  SUBSTR(Telefonnummer, 5, 3) NOT LIKE '% %'
  AND
  -- >= 150
  INT(SUBSTR(TELEFONNUMMER, 5, 3)) >= 150
  AND
  -- <= 180
  INT(SUBSTR(TELEFONNUMMER, 5, 3)) <= 180
  AND
  -- followed by space
  SUBSTR(TELEFONNUMMER, 8, 1) LIKE ' '
  AND
  -- no spaces
  SUBSTR(Telefonnummer,9) NOT LIKE '% %'
  AND
  -- only numbers
  LENGTH(REPLACE(TRANSLATE(SUBSTR(TELEFONNUMMER, 9), '','0123456789'), ' ', '')) = 0
  AND
  -- 8 - 9 digits
  LENGTH(SUBSTR(TELEFONNUMMER, 9)) >= 8
  AND
  LENGTH(SUBSTR(TELEFONNUMMER, 9)) <= 10
);