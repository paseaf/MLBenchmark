-- Aufgabe 4:
-- Funktion um der Tabelle KundenKontaktDaten ein check constraint
-- mit dem Namen GoogleUndFacebookID_CHECK auf die Attribute Google_ID und
-- Facebook_ID hinzuzufügen.
--
-- Das Check Constraint soll sicher stellen dass:
-- - Alle Google und FacebookIDs im Intervall [10000000,99999999] liegen.
-- - Keine verbotenen IDs verwendet werden.
-- o Google verbietet: 10000042, 10000007, 10000666
-- o Facebook verbietet: 10004321, 10097242, 12345678
--
-- Punkte:
-- 1
--
ALTER TABLE KUNDENKONTAKTDATEN
ADD CONSTRAINT GoogleUndFacebookID_CHECK
CHECK(
  GOOGLE_ID >= 10000000
  AND
  GOOGLE_ID <= 99999999
  AND
  GOOGLE_ID <> 10000042
  AND
  GOOGLE_ID <> 10000007
  AND
  GOOGLE_ID <> 10000666
  AND
  FACEBOOK_ID >= 10000000
  AND
  FACEBOOK_ID <= 99999999
  AND
  FACEBOOK_ID <> 10004321
  AND
  FACEBOOK_ID <> 10097242
  AND
  FACEBOOK_ID <> 12345678
);