-- Queryergebnis:
-- Berechnen sie für jeden Kunden, wie viele seiner Bestellungen vollständig mit Artikeln von lokalen Lieferanten erfüllt worden sind.
-- Lokaler Lieferant bedeutet, dass der Lieferant in dem gleichen Land wie der Kunde ansässig ist.
-- Geben sie alle Kunden aus, die mindestens eine solche lokale Bestellung hatten, absteigend nach der Anzahl der lokalen Bestellungen.
--
-- Ergebnisschema:
-- [KundenName(↑2) | Anzahl (↓1)]
--
-- Punkte:
-- 1.5
--

SELECT a.KUNDE_NAME AS KUNDENNAME, COUNT(a.BESTELLUNG_BESTELL_NR) AS ANZAHL
FROM(
  SELECT KUNDE_NAME, BESTELLUNG_BESTELL_NR, COUNT(LIEFERANT) AS ANZAHL
  FROM (
    SELECT
      KUNDEN_NR_A,
      KUNDE_NAME,
      KUNDE_LAND,
      BESTELLUNG_BESTELL_NR,
      LIEFERANT
    FROM (
      -- kunde -> bestellungen --> bestellposten / lieferant
      SELECT
        KUNDEN_NR AS KUNDEN_NR_A,
        BESTELLUNG_BESTELL_NR,
        LIEFERANT
      FROM (
        -- kunde und bestellungen
        SELECT
          KUNDEN_NR,
          BESTELL_NR AS KUNDE_BESTELL_NR
        FROM KUNDE
          JOIN BESTELLUNG
            ON KUNDEN_NR = KUNDE
        )
        JOIN (
          -- bestellung und bestellposten/lieferant
          SELECT
            BESTELLUNG.BESTELL_NR AS BESTELLUNG_BESTELL_NR,
            LIEFERANT
          FROM BESTELLUNG
            JOIN BESTELLPOSTEN
              ON BESTELLUNG.BESTELL_NR = BESTELLPOSTEN.BESTELL_NR
          )
          ON KUNDE_BESTELL_NR = BESTELLUNG_BESTELL_NR
      GROUP BY KUNDEN_NR, BESTELLUNG_BESTELL_NR, LIEFERANT
      ORDER BY KUNDEN_NR, BESTELLUNG_BESTELL_NR, LIEFERANT
      ) JOIN (
      -- name und land von kunde
      SELECT
        KUNDEN_NR  AS KUNDEN_NR_B,
        KUNDE.NAME AS KUNDE_NAME,
        LAND.NAME  AS KUNDE_LAND
      FROM KUNDE
        JOIN LAND
          ON LAND = LAND_ID
      )
        ON KUNDEN_NR_A = KUNDEN_NR_B
    ORDER BY KUNDEN_NR_A
    ) JOIN (
    SELECT LIEFERANTEN_NR, LAND.NAME AS LIEFERANT_LAND
    FROM LIEFERANT
      JOIN LAND
        ON LAND = LAND_ID
    )
      ON LIEFERANT = LIEFERANTEN_NR
  GROUP BY KUNDE_NAME, BESTELLUNG_BESTELL_NR
  ORDER BY KUNDE_NAME
) AS a,
( SELECT KUNDE_NAME, BESTELLUNG_BESTELL_NR, COUNT(LIEFERANT) AS ANZAHL
  FROM (
    SELECT
      KUNDEN_NR_A,
      KUNDE_NAME,
      KUNDE_LAND,
      BESTELLUNG_BESTELL_NR,
      LIEFERANT
    FROM (
      -- kunde -> bestellungen --> bestellposten / lieferant
      SELECT
        KUNDEN_NR AS KUNDEN_NR_A,
        BESTELLUNG_BESTELL_NR,
        LIEFERANT
      FROM (
        -- kunde und bestellungen
        SELECT
          KUNDEN_NR,
          BESTELL_NR AS KUNDE_BESTELL_NR
        FROM KUNDE
          JOIN BESTELLUNG
            ON KUNDEN_NR = KUNDE
        )
        JOIN (
          -- bestellung -> bestellposten/lieferant
          SELECT
            BESTELLUNG.BESTELL_NR AS BESTELLUNG_BESTELL_NR,
            LIEFERANT
          FROM BESTELLUNG
            JOIN BESTELLPOSTEN
              ON BESTELLUNG.BESTELL_NR = BESTELLPOSTEN.BESTELL_NR
          )
          ON KUNDE_BESTELL_NR = BESTELLUNG_BESTELL_NR
      GROUP BY KUNDEN_NR, BESTELLUNG_BESTELL_NR, LIEFERANT
      ORDER BY KUNDEN_NR, BESTELLUNG_BESTELL_NR, LIEFERANT
      ) JOIN (
      -- name und land von kunde
      SELECT
        KUNDEN_NR  AS KUNDEN_NR_B,
        KUNDE.NAME AS KUNDE_NAME,
        LAND.NAME  AS KUNDE_LAND
      FROM KUNDE
        JOIN LAND
          ON LAND = LAND_ID
      )
        ON KUNDEN_NR_A = KUNDEN_NR_B
    ORDER BY KUNDEN_NR_A
    ) JOIN (
    SELECT LIEFERANTEN_NR, LAND.NAME AS LIEFERANT_LAND
    FROM LIEFERANT
      JOIN LAND
        ON LAND = LAND_ID
    )
      ON LIEFERANT = LIEFERANTEN_NR
  WHERE KUNDE_LAND = LIEFERANT_LAND
  GROUP BY KUNDE_NAME, BESTELLUNG_BESTELL_NR
) AS b
WHERE a.KUNDE_NAME = b.KUNDE_NAME
      AND a.BESTELLUNG_BESTELL_NR = b.BESTELLUNG_BESTELL_NR
      AND a.ANZAHL = b.ANZAHL
GROUP BY a.KUNDE_NAME
ORDER BY COUNT(a.BESTELLUNG_BESTELL_NR) DESC, a.KUNDE_NAME ASC