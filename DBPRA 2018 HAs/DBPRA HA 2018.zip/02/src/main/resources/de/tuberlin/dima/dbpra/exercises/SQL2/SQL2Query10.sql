-- Queryergebnis:
-- Bestimmen Sie für alle Lieferanten aus "FRANCE" jeweils die Artikel, bei denen der verfügbare Lieferwert mehr ist,
-- als 1/500 des verfügbaren Lieferwertes aller Artikel dieses Lieferanten.
-- Der verfügbare Lieferwert eines Artikels ist das Produkt aus der verfügbaren Anzahl und dem Preis.
--
-- Ergebnisschema:
-- [Lieferanten_Nr (↑1) | Artikel (ID) | Wert (↓2)]
--
-- Punkte:
-- 1.5
--

SELECT a.LIEFERANTEN_NR AS LIEFERANTEN_NR, a.ARTIKEL_NR AS ARTIKEL, a.ARTIKEL_VERF_LIEFERWERT AS WERT
FROM
  -- lieferanten aus frankreich mit artikeln und deren lieferwert
  (SELECT LIEFERANTEN_NR, ARTIKEL_NR, ARTIKEL_VERF_LIEFERWERT
   FROM
     -- lieferanten aus frankreich
     (SELECT LIEFERANTEN_NR
      FROM LIEFERANT
        JOIN LAND
          ON LIEFERANT.LAND = LAND.LAND_ID
      WHERE LAND.NAME = 'FRANCE')
     JOIN
     -- alle artikel eines lieferanten mit verfügbarem lieferwert
     (SELECT LIEFERANT, ARTIKEL_NR, (LIEFERPREIS * LIEFERT.ANZAHL_VERFUEGB) ARTIKEL_VERF_LIEFERWERT
      FROM ARTIKEL
        JOIN LIEFERT
          ON ARTIKEL.ARTIKEL_NR = LIEFERT.ARTIKEL
      ORDER BY LIEFERANT, ARTIKEL_NR)
       ON LIEFERANTEN_NR = LIEFERANT) AS a,
  (SELECT LIEFERANT, (SUM(LIEFERPREIS * LIEFERT.ANZAHL_VERFUEGB) / 500) AS LIEFERANT_VERF_LIEFERWERT
   FROM ARTIKEL
     JOIN LIEFERT
       ON ARTIKEL.ARTIKEL_NR = LIEFERT.ARTIKEL
   GROUP BY LIEFERANT) AS b
WHERE a.LIEFERANTEN_NR = b.LIEFERANT AND a.ARTIKEL_VERF_LIEFERWERT > b.LIEFERANT_VERF_LIEFERWERT
ORDER BY a.LIEFERANTEN_NR ASC, a.ARTIKEL_VERF_LIEFERWERT DESC