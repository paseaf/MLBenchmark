-- Queryergebnis:
-- Finden sie für jeden Artikel des Typs "MEDIUM ANODIZED TIN" den Lieferanten aus der Region 'ASIA',
-- der für den Artikel den niedrigsten Lieferpreis hat.
-- Der Lieferpreis eines Lieferanten für einen Artikel ist das gleichnamige Attribut auf der "Liefert" Relation.
--
-- Ergebnisschema:
-- [Artikel_Nr (↑) | Lieferant_Name (↑) | Lieferpreis]
--
-- Punkte:
-- 1.0
--

SELECT ARTIKEL_NR, NAME AS LIEFERANT_NAME, LIEFERPREIS
FROM(
  -- artikel vom typ 'tin' von lieferanten aus asien
  SELECT ARTIKEL_NR, NAME, LIEFERPREIS
  FROM(
    -- lieferanten von artikel vom typ 'tin'
    SELECT ARTIKEL_NR, LIEFERANT, LIEFERPREIS
    FROM LIEFERT JOIN (SELECT ARTIKEL_NR FROM ARTIKEL WHERE TYP = 'MEDIUM ANODIZED TIN')
    ON ARTIKEL = ARTIKEL_NR
  )
  JOIN(
    -- lieferanten aus region asien
    SELECT LIEFERANTEN_NR, NAME
    FROM LIEFERANT JOIN(
      SELECT LAND_ID
      FROM REGION JOIN LAND
      ON REGION_ID = REGION
      WHERE REGION.NAME = 'ASIA'
    )
    ON LAND = LAND_ID
  )
  ON LIEFERANT = LIEFERANTEN_NR
) AS a
JOIN(
  -- min preis für jeden artikel vom typ 'tin' von lieferant aus region asien
  SELECT MIN(LIEFERPREIS) AS MIN_LIEFERPREIS
  FROM(
    SELECT ARTIKEL_NR, LIEFERANT, LIEFERPREIS
    FROM LIEFERT JOIN (SELECT ARTIKEL_NR FROM ARTIKEL WHERE TYP = 'MEDIUM ANODIZED TIN')
    ON ARTIKEL = ARTIKEL_NR)
  JOIN(
    SELECT LIEFERANTEN_NR, NAME
    FROM LIEFERANT JOIN(
      SELECT LAND_ID
      FROM REGION JOIN LAND
      ON REGION_ID = REGION
      WHERE REGION.NAME = 'ASIA'
    )
    ON LAND = LAND_ID
  )
  ON LIEFERANT = LIEFERANTEN_NR
  GROUP BY ARTIKEL_NR
) AS b
ON a.LIEFERPREIS = b.MIN_LIEFERPREIS
ORDER BY ARTIKEL_NR ASC, LIEFERANT_NAME ASC