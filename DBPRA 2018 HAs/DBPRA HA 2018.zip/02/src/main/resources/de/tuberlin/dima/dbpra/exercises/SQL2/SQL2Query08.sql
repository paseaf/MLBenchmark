-- Queryergebnis:
-- Finden Sie für alle Marken diejenigen Artikel, die in den obersten 1% der Preisspanne der Marke sind.
-- Die Preisspanne ist die Differenz zwischen dem billigsten und dem teuersten Artikel.
--
-- Ergebnisschema:
-- [Marke (↑1) | Name (↑2) ]
--
-- Punkte:
-- 1.0
--
-- @return SQL Query für Aufgabe 8
--

SELECT a.MARKE, a.NAME
FROM (
  SELECT
    MARKE,
    NAME,
    PREIS
  FROM ARTIKEL
  GROUP BY MARKE, NAME, PREIS
  ORDER BY MARKE, NAME, PREIS
) AS a,
  (SELECT MARKE, (MIN(PREIS) + (MAX(PREIS) - MIN(PREIS)) * 0.99) AS one_perc
   FROM ARTIKEL
   GROUP BY MARKE) AS b
WHERE a.MARKE = b.MARKE AND a.PREIS >= b.one_perc
ORDER BY a.MARKE ASC, a.NAME ASC